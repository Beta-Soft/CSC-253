﻿namespace WinsUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.conversionListBox = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // conversionListBox
            // 
            this.conversionListBox.FormattingEnabled = true;
            this.conversionListBox.Location = new System.Drawing.Point(0, 0);
            this.conversionListBox.Name = "conversionListBox";
            this.conversionListBox.Size = new System.Drawing.Size(274, 368);
            this.conversionListBox.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(245, 315);
            this.Controls.Add(this.conversionListBox);
            this.Name = "Form1";
            this.Text = "C to F Table";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox conversionListBox;
    }
}

