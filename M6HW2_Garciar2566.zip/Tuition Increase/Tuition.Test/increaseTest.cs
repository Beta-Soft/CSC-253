﻿/**
* CSC 253
* Rebecca Garcia 
* M6HW2 - Unit Testing
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tuition.Test
{
    public class increaseTest
    {
        
        public void addTwoNums()
        {
            // arrange
            int num1 = 6;
            int num2 = 5;

            int expected = 11;

            // act
            var result = TuitionLibrary.increaseTuition.addTwoNum(num1, num2);

            // assert
            Assert.AreEqual(expected, result);

        }
    }
}