﻿/**
* CSC 253
* Rebecca Garcia 
* M6HW2 - Unit Testing
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TuitionLibrary
{
    public static class increaseTuition
    {
        public static List<string> TuitionRate()
        {
            List<string> output = new List<string>(); 

            for (int index = 1; index <= 5; index++)
            {
                decimal tuition = 6000m;
                decimal increase = tuition * .02m;
                tuition = tuition + increase;
                string tuitionconvert = $"{tuition:c}";
                output.Add($"Year {index} : {tuitionconvert}");
            }
                return output;
        }

        public static int addTwoNum(int x, int y)
        {
            return x + y;
        }
    }
      
}
