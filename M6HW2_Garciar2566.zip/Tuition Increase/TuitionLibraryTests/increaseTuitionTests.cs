﻿/**
* CSC 253
* Rebecca Garcia 
* M6HW2 - Unit Testing
*/

using Microsoft.VisualStudio.TestTools.UnitTesting;
using TuitionLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TuitionLibrary.Tests
{
    [TestClass()]
    public class increaseTuitionTests
    {
        [TestMethod()]
        public void addTwoNumTest()
        {
            // arrange
            int num1 = 6;
            int num2 = 5;

            int expected = 11;

            // act
            var result = TuitionLibrary.increaseTuition.addTwoNum(num1, num2);

            // assert
            Assert.AreEqual(expected, result);
        }
    }
}