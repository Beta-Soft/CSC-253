﻿/**
* 24102021
* CSC 253
* Rebecca Garcia
* M5HW1 - Employee & Worker Classes
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace empProLibrary
{
    class teamLeaderClass : productionWorkerClass // colon indicates derived from another
    {
        public teamLeaderClass(string empname, string empnum, string shiftnum, int hourlypay, decimal monthlybonus, 
            decimal reqtraininghours, decimal aqtraininghours) : base(empname, empnum, shiftnum, hourlypay)
        {
            monthlyBonus = monthlybonus;
            reqTrainingHours = reqtraininghours;
            aqTrainingHours = aqtraininghours;
        }

        // auto prop
        public decimal monthlyBonus { get; set; }
        public decimal reqTrainingHours { get; set; }
        public decimal aqTrainingHours { get; set; }

    }
}
