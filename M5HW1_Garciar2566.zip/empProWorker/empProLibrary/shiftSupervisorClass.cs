﻿/**
* 24102021
* CSC 253
* Rebecca Garcia
* M5HW1 - Employee & Worker Classes
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace empProLibrary
{
    class shiftSupervisorClass : employeeClass // colon indicates derived from another
    {
        public shiftSupervisorClass(string empname, string empnum, decimal annualsalary, decimal annualproduction) : base(empname, empnum)
        {
            annualSalary     = annualsalary;
            annualProduction = annualproduction;
        }

        // auto prop
        public decimal annualSalary { get; set; }

        public decimal annualProduction { get; set; }
    }
}
