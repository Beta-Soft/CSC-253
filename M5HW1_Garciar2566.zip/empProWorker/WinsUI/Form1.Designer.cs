﻿
namespace WinsUI
{
    partial class M5HW1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.nameLabel = new System.Windows.Forms.Label();
            this.numberLabel = new System.Windows.Forms.Label();
            this.shiftLabel = new System.Windows.Forms.Label();
            this.payLabel = new System.Windows.Forms.Label();
            this.nameTextbox = new System.Windows.Forms.TextBox();
            this.numTextbox = new System.Windows.Forms.TextBox();
            this.shiftTextbox = new System.Windows.Forms.TextBox();
            this.payTextbox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.nameDisplay = new System.Windows.Forms.Label();
            this.numDisplay = new System.Windows.Forms.Label();
            this.shiftDisplay = new System.Windows.Forms.Label();
            this.payDisplay = new System.Windows.Forms.Label();
            this.addButton = new System.Windows.Forms.Button();
            this.titleLabel = new System.Windows.Forms.Label();
            this.clearButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // nameLabel
            // 
            this.nameLabel.AutoSize = true;
            this.nameLabel.Location = new System.Drawing.Point(32, 88);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(90, 13);
            this.nameLabel.TabIndex = 0;
            this.nameLabel.Text = "Employee Name: ";
            // 
            // numberLabel
            // 
            this.numberLabel.AutoSize = true;
            this.numberLabel.Location = new System.Drawing.Point(23, 126);
            this.numberLabel.Name = "numberLabel";
            this.numberLabel.Size = new System.Drawing.Size(99, 13);
            this.numberLabel.TabIndex = 1;
            this.numberLabel.Text = "Employee Number: ";
            // 
            // shiftLabel
            // 
            this.shiftLabel.AutoSize = true;
            this.shiftLabel.Location = new System.Drawing.Point(48, 161);
            this.shiftLabel.Name = "shiftLabel";
            this.shiftLabel.Size = new System.Drawing.Size(74, 13);
            this.shiftLabel.TabIndex = 2;
            this.shiftLabel.Text = "Shift Number: ";
            // 
            // payLabel
            // 
            this.payLabel.AutoSize = true;
            this.payLabel.Location = new System.Drawing.Point(32, 194);
            this.payLabel.Name = "payLabel";
            this.payLabel.Size = new System.Drawing.Size(90, 13);
            this.payLabel.TabIndex = 3;
            this.payLabel.Text = "Hourly Pay Rate: ";
            // 
            // nameTextbox
            // 
            this.nameTextbox.Location = new System.Drawing.Point(139, 85);
            this.nameTextbox.Multiline = true;
            this.nameTextbox.Name = "nameTextbox";
            this.nameTextbox.Size = new System.Drawing.Size(153, 23);
            this.nameTextbox.TabIndex = 1;
            // 
            // numTextbox
            // 
            this.numTextbox.Location = new System.Drawing.Point(139, 120);
            this.numTextbox.Multiline = true;
            this.numTextbox.Name = "numTextbox";
            this.numTextbox.Size = new System.Drawing.Size(153, 23);
            this.numTextbox.TabIndex = 2;
            // 
            // shiftTextbox
            // 
            this.shiftTextbox.Location = new System.Drawing.Point(139, 155);
            this.shiftTextbox.Multiline = true;
            this.shiftTextbox.Name = "shiftTextbox";
            this.shiftTextbox.Size = new System.Drawing.Size(153, 23);
            this.shiftTextbox.TabIndex = 3;
            // 
            // payTextbox
            // 
            this.payTextbox.Location = new System.Drawing.Point(139, 190);
            this.payTextbox.Multiline = true;
            this.payTextbox.Name = "payTextbox";
            this.payTextbox.Size = new System.Drawing.Size(153, 23);
            this.payTextbox.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(32, 281);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(90, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Employee Name: ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(23, 317);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(99, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Employee Number: ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(48, 356);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "Shift Number: ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(32, 398);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(90, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "Hourly Pay Rate: ";
            // 
            // nameDisplay
            // 
            this.nameDisplay.BackColor = System.Drawing.SystemColors.Info;
            this.nameDisplay.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.nameDisplay.Location = new System.Drawing.Point(139, 281);
            this.nameDisplay.Name = "nameDisplay";
            this.nameDisplay.Size = new System.Drawing.Size(153, 23);
            this.nameDisplay.TabIndex = 13;
            this.nameDisplay.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // numDisplay
            // 
            this.numDisplay.BackColor = System.Drawing.SystemColors.Info;
            this.numDisplay.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.numDisplay.Location = new System.Drawing.Point(139, 317);
            this.numDisplay.Name = "numDisplay";
            this.numDisplay.Size = new System.Drawing.Size(153, 23);
            this.numDisplay.TabIndex = 14;
            this.numDisplay.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // shiftDisplay
            // 
            this.shiftDisplay.BackColor = System.Drawing.SystemColors.Info;
            this.shiftDisplay.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.shiftDisplay.Location = new System.Drawing.Point(139, 356);
            this.shiftDisplay.Name = "shiftDisplay";
            this.shiftDisplay.Size = new System.Drawing.Size(153, 23);
            this.shiftDisplay.TabIndex = 15;
            this.shiftDisplay.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // payDisplay
            // 
            this.payDisplay.BackColor = System.Drawing.SystemColors.Info;
            this.payDisplay.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.payDisplay.Location = new System.Drawing.Point(139, 398);
            this.payDisplay.Name = "payDisplay";
            this.payDisplay.Size = new System.Drawing.Size(153, 23);
            this.payDisplay.TabIndex = 16;
            this.payDisplay.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // addButton
            // 
            this.addButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.addButton.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.addButton.Location = new System.Drawing.Point(108, 229);
            this.addButton.Name = "addButton";
            this.addButton.Size = new System.Drawing.Size(85, 34);
            this.addButton.TabIndex = 5;
            this.addButton.Text = "Add Employee";
            this.addButton.UseVisualStyleBackColor = true;
            this.addButton.Click += new System.EventHandler(this.addButton_Click);
            // 
            // titleLabel
            // 
            this.titleLabel.AutoSize = true;
            this.titleLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titleLabel.Location = new System.Drawing.Point(30, 20);
            this.titleLabel.Name = "titleLabel";
            this.titleLabel.Size = new System.Drawing.Size(267, 50);
            this.titleLabel.TabIndex = 18;
            this.titleLabel.Text = "Employee and\r\nProductionWorker Classes";
            this.titleLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // clearButton
            // 
            this.clearButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.clearButton.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.clearButton.Location = new System.Drawing.Point(108, 444);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(85, 34);
            this.clearButton.TabIndex = 6;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // M5HW1
            // 
            this.AcceptButton = this.addButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(324, 490);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.titleLabel);
            this.Controls.Add(this.payLabel);
            this.Controls.Add(this.payTextbox);
            this.Controls.Add(this.shiftLabel);
            this.Controls.Add(this.nameLabel);
            this.Controls.Add(this.shiftTextbox);
            this.Controls.Add(this.addButton);
            this.Controls.Add(this.numTextbox);
            this.Controls.Add(this.payDisplay);
            this.Controls.Add(this.nameTextbox);
            this.Controls.Add(this.shiftDisplay);
            this.Controls.Add(this.numDisplay);
            this.Controls.Add(this.nameDisplay);
            this.Controls.Add(this.numberLabel);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "M5HW1";
            this.Text = "M5HW1_Garciar2566";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.Label numberLabel;
        private System.Windows.Forms.Label shiftLabel;
        private System.Windows.Forms.Label payLabel;
        private System.Windows.Forms.TextBox nameTextbox;
        private System.Windows.Forms.TextBox numTextbox;
        private System.Windows.Forms.TextBox shiftTextbox;
        private System.Windows.Forms.TextBox payTextbox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label nameDisplay;
        private System.Windows.Forms.Label numDisplay;
        private System.Windows.Forms.Label shiftDisplay;
        private System.Windows.Forms.Label payDisplay;
        private System.Windows.Forms.Button addButton;
        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.Button clearButton;
    }
}

