﻿/**
* 05092021
* CSC 253
* Rebecca Garcia
* Word Count Assignment
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinsUI
{
    class WordCount
    {
        public WordCount(string userText)
        {
            usertext = userText;
        }

        public string usertext { get; set; }
    }
}
