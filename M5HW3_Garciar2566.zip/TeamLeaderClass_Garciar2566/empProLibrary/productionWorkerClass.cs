﻿/**
* 24102021
* CSC 253
* Rebecca Garcia
* M5HW3 - TeamLeader Class
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace empProLibrary
{
    public class productionWorkerClass : employeeClass // colon indicates derived from another
    {
        public productionWorkerClass(string empname, string empnum, string shiftnum, decimal hourlypay) : base(empname, empnum)
        {
            shiftNum = shiftnum;
            hourlyPay = hourlypay;            
        }

        // auto prop
        public string shiftNum { get; set; }

        public decimal hourlyPay { get; set; }
    }
}
