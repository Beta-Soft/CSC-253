﻿/**
* 24102021
* CSC 253
* Rebecca Garcia
* M5HW3 - TeamLeader Class
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace empProLibrary
{
    public class shiftSupervisorClass : employeeClass // colon indicates derived from another
    {
        public shiftSupervisorClass(string empname, string empnum, decimal annualsalary, decimal annualbonus) : base(empname, empnum)
        {
            annualSalary     = annualsalary;
            annualBonus      = annualbonus;
        }

        // auto prop
        public decimal annualSalary { get; set; }

        public decimal  annualBonus { get; set; }
    }
}
