﻿/**
* 24102021
* CSC 253
* Rebecca Garcia
* M5HW3 - TeamLeader Class
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace empProLibrary
{
    public class teamLeaderClass : productionWorkerClass // colon indicates derived from another
    {
        public teamLeaderClass(string empname, string empnum, string shiftnum, decimal hourlypay, int monthlybonus, 
            int reqtraininghours, int aqtraininghours) : base(empname, empnum, shiftnum, hourlypay)
        {
            monthlyBonus = monthlybonus;
            reqTrainingHours = reqtraininghours;
            aqTrainingHours = aqtraininghours;
        }

        // auto prop
        public int monthlyBonus { get; set; }
        public int reqTrainingHours { get; set; }
        public int aqTrainingHours { get; set; }

    }
}
