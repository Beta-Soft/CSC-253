﻿/**
* 03102021
* CSC 253
* Rebecca Garcia
* M4HW2 DataGridView Buttons
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WinsUI
{
    public partial class searchForm : Form
    {
        public searchForm()
        {
            InitializeComponent();
        }

        private void employeeBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.employeeBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.personnelDataSet);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // loads data into 'personnelDataSet.Employee' table
            this.employeeTableAdapter.Fill(this.personnelDataSet.Employee);

        }

        private void buttonAscend_Click(object sender, EventArgs e)
        {
            // sorts table by Hourly Pay ascending order
            this.employeeTableAdapter.Ascending(this.personnelDataSet.Employee);

        }

        private void buttonDescend_Click(object sender, EventArgs e)
        {
            // sorts table by Hourly Pay descending order
            this.employeeTableAdapter.Descending(this.personnelDataSet.Employee);
        }

        private void buttonRefresh_Click(object sender, EventArgs e)
        {
            // table displays back to how it did on start up
            this.employeeTableAdapter.Fill(this.personnelDataSet.Employee);
            searchTextBox.Clear();
        }

        private void buttonSearch_Click(object sender, EventArgs e)
        {
            // searches employee
            this.employeeTableAdapter.searchName(this.personnelDataSet.Employee, searchTextBox.Text);
        }
    }
}
