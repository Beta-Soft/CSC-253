﻿namespace WinsUI
{


    partial class PersonnelDataSet
    {
    }
}

namespace WinsUI.PersonnelDataSetTableAdapters {
    
    
    public partial class EmployeeTableAdapter {
    }
}
