﻿/**
* 11092021
* CSC 253
* Rebecca Garcia
* Frequent Character
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinUI
{
    public partial class freqForm : Form
    {
        public freqForm()
        {
            InitializeComponent();
        }

        private void findButton_Click(object sender, EventArgs e)
        {
            string input;
            int[] frequency = new int[255]; // num of char
            int i = 0, max = 0, length;
            int ascii;

            input = stringyText.Text;

            length = input.Length;

            for (i = 0; i < 255; i++)
            {
                frequency[i] = 0;
            }

            // finds frequency
            i = 0;
            while (i < length)
            {
                ascii = (int)input[i];
                frequency[ascii] += 1;

                i++;
            }

            // finds max freq
            for (i = 0; i < 255; i++)
            {
                if (i != 32)
                {
                    if (frequency[i] > frequency[max])
                        max = i;
                }
            }

            displayBox.Items.Add("Highest frequency character: " + (char)max);
            displayBox.Items.Add("# of times \"" + (char)max + "\" appears: " + frequency[max]);
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close(); // closes prog
        }

        private void newButton_Click(object sender, EventArgs e)
        {
            stringyText.Clear();
            displayBox.Items.Add("----------------------------");
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            displayBox.Items.Clear();
        }
    }
}