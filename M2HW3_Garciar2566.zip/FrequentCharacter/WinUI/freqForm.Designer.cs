﻿
namespace WinUI
{
    partial class freqForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.stringyText = new System.Windows.Forms.TextBox();
            this.inputLabel = new System.Windows.Forms.Label();
            this.findButton = new System.Windows.Forms.Button();
            this.displayBox = new System.Windows.Forms.ListBox();
            this.newButton = new System.Windows.Forms.Button();
            this.title = new System.Windows.Forms.Label();
            this.exitButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // stringyText
            // 
            this.stringyText.Location = new System.Drawing.Point(82, 43);
            this.stringyText.Name = "stringyText";
            this.stringyText.Size = new System.Drawing.Size(166, 20);
            this.stringyText.TabIndex = 1;
            // 
            // inputLabel
            // 
            this.inputLabel.AutoSize = true;
            this.inputLabel.Location = new System.Drawing.Point(12, 43);
            this.inputLabel.Name = "inputLabel";
            this.inputLabel.Size = new System.Drawing.Size(64, 13);
            this.inputLabel.TabIndex = 3;
            this.inputLabel.Text = "Input String:";
            // 
            // findButton
            // 
            this.findButton.Location = new System.Drawing.Point(37, 69);
            this.findButton.Name = "findButton";
            this.findButton.Size = new System.Drawing.Size(81, 22);
            this.findButton.TabIndex = 2;
            this.findButton.Text = "Find Frequent Character";
            this.findButton.UseVisualStyleBackColor = true;
            this.findButton.Click += new System.EventHandler(this.findButton_Click);
            // 
            // displayBox
            // 
            this.displayBox.FormattingEnabled = true;
            this.displayBox.Location = new System.Drawing.Point(15, 104);
            this.displayBox.Name = "displayBox";
            this.displayBox.Size = new System.Drawing.Size(233, 121);
            this.displayBox.TabIndex = 6;
            // 
            // newButton
            // 
            this.newButton.Location = new System.Drawing.Point(137, 69);
            this.newButton.Name = "newButton";
            this.newButton.Size = new System.Drawing.Size(81, 22);
            this.newButton.TabIndex = 3;
            this.newButton.Text = "New Input";
            this.newButton.UseVisualStyleBackColor = true;
            this.newButton.Click += new System.EventHandler(this.newButton_Click);
            // 
            // title
            // 
            this.title.AutoSize = true;
            this.title.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.title.Location = new System.Drawing.Point(23, 9);
            this.title.Name = "title";
            this.title.Size = new System.Drawing.Size(216, 25);
            this.title.TabIndex = 8;
            this.title.Text = "Frequent Character";
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(137, 231);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(81, 22);
            this.exitButton.TabIndex = 5;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(37, 231);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(81, 22);
            this.clearButton.TabIndex = 4;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // freqForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(266, 265);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.title);
            this.Controls.Add(this.newButton);
            this.Controls.Add(this.displayBox);
            this.Controls.Add(this.findButton);
            this.Controls.Add(this.inputLabel);
            this.Controls.Add(this.stringyText);
            this.Name = "freqForm";
            this.Text = "M2HW3_garciar2566";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox stringyText;
        private System.Windows.Forms.Label inputLabel;
        private System.Windows.Forms.Button findButton;
        private System.Windows.Forms.ListBox displayBox;
        private System.Windows.Forms.Button newButton;
        private System.Windows.Forms.Label title;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button clearButton;
    }
}

