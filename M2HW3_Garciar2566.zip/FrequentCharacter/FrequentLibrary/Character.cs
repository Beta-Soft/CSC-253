﻿/**
* 11092021
* CSC 253
* Rebecca Garcia
* Frequent Character
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FrequentLibrary
{
    public class Character
    {

        // TODO: add majority of findButton click code here
    }
}
