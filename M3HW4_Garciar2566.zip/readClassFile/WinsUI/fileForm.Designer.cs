﻿namespace WinsUI
{
    partial class readClassFile
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelName = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.labelType = new System.Windows.Forms.Label();
            this.txtType = new System.Windows.Forms.TextBox();
            this.labelAge = new System.Windows.Forms.Label();
            this.txtAge = new System.Windows.Forms.TextBox();
            this.submitButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.displayBox = new System.Windows.Forms.ListBox();
            this.toFileTitle = new System.Windows.Forms.Label();
            this.readButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Location = new System.Drawing.Point(12, 59);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(54, 13);
            this.labelName.TabIndex = 1;
            this.labelName.Text = "Pet Name";
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(95, 56);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(134, 20);
            this.txtName.TabIndex = 1;
            // 
            // labelType
            // 
            this.labelType.AutoSize = true;
            this.labelType.Location = new System.Drawing.Point(12, 85);
            this.labelType.Name = "labelType";
            this.labelType.Size = new System.Drawing.Size(50, 13);
            this.labelType.TabIndex = 5;
            this.labelType.Text = "Pet Type";
            // 
            // txtType
            // 
            this.txtType.Location = new System.Drawing.Point(95, 82);
            this.txtType.Name = "txtType";
            this.txtType.Size = new System.Drawing.Size(134, 20);
            this.txtType.TabIndex = 2;
            // 
            // labelAge
            // 
            this.labelAge.AutoSize = true;
            this.labelAge.Location = new System.Drawing.Point(12, 110);
            this.labelAge.Name = "labelAge";
            this.labelAge.Size = new System.Drawing.Size(45, 13);
            this.labelAge.TabIndex = 7;
            this.labelAge.Text = "Pet Age";
            // 
            // txtAge
            // 
            this.txtAge.Location = new System.Drawing.Point(95, 107);
            this.txtAge.Name = "txtAge";
            this.txtAge.Size = new System.Drawing.Size(134, 20);
            this.txtAge.TabIndex = 3;
            // 
            // submitButton
            // 
            this.submitButton.BackColor = System.Drawing.SystemColors.HotTrack;
            this.submitButton.Location = new System.Drawing.Point(26, 142);
            this.submitButton.Name = "submitButton";
            this.submitButton.Size = new System.Drawing.Size(61, 40);
            this.submitButton.TabIndex = 4;
            this.submitButton.Text = "Submit To File";
            this.submitButton.UseVisualStyleBackColor = false;
            this.submitButton.Click += new System.EventHandler(this.submitButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.BackColor = System.Drawing.SystemColors.HotTrack;
            this.exitButton.Location = new System.Drawing.Point(82, 302);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(61, 38);
            this.exitButton.TabIndex = 6;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = false;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // displayBox
            // 
            this.displayBox.FormattingEnabled = true;
            this.displayBox.Location = new System.Drawing.Point(15, 188);
            this.displayBox.Name = "displayBox";
            this.displayBox.Size = new System.Drawing.Size(214, 108);
            this.displayBox.TabIndex = 12;
            // 
            // toFileTitle
            // 
            this.toFileTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toFileTitle.Location = new System.Drawing.Point(-19, -2);
            this.toFileTitle.Name = "toFileTitle";
            this.toFileTitle.Size = new System.Drawing.Size(280, 58);
            this.toFileTitle.TabIndex = 23;
            this.toFileTitle.Text = "ADD/READ FILE";
            this.toFileTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // readButton
            // 
            this.readButton.BackColor = System.Drawing.SystemColors.HotTrack;
            this.readButton.Location = new System.Drawing.Point(158, 142);
            this.readButton.Name = "readButton";
            this.readButton.Size = new System.Drawing.Size(61, 40);
            this.readButton.TabIndex = 5;
            this.readButton.Text = "Read File";
            this.readButton.UseVisualStyleBackColor = false;
            this.readButton.Click += new System.EventHandler(this.readButton_Click);
            // 
            // readClassFile
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(241, 344);
            this.Controls.Add(this.readButton);
            this.Controls.Add(this.toFileTitle);
            this.Controls.Add(this.displayBox);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.submitButton);
            this.Controls.Add(this.txtAge);
            this.Controls.Add(this.labelAge);
            this.Controls.Add(this.txtType);
            this.Controls.Add(this.labelType);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.labelName);
            this.Name = "readClassFile";
            this.Text = "Pet Info";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label labelType;
        private System.Windows.Forms.TextBox txtType;
        private System.Windows.Forms.Label labelAge;
        private System.Windows.Forms.TextBox txtAge;
        private System.Windows.Forms.Button submitButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.ListBox displayBox;
        private System.Windows.Forms.Label toFileTitle;
        private System.Windows.Forms.Button readButton;
    }
}

