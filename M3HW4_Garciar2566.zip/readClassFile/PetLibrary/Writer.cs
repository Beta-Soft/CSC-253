﻿/**
* 26092021
* CSC 253
* Rebecca Garcia
* Class to & from File
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace PetLibrary
{
    public class Writer
    {
        public static string writerFile(string name, string type, decimal age)
        {
            //  lets create new file
            StreamWriter fileWrite;

            try // displays if added or not by calling var used to create file
            {
                fileWrite = File.AppendText("Pet Info.txt");

                // writeline formatting
                fileWrite.WriteLine($"{name}, {type}, {age}");
                fileWrite.Close();
                return "Pet Info added to file";
            }
            catch (Exception ex)
            {
               return ex.Message;
            }
        }
    }
}
