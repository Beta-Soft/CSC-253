﻿/**
* 26092021
* CSC 253
* Rebecca Garcia
* Class to & from File
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace PetLibrary
{
    public class Reader
    {
        public static string CreateClass()
        {
            //  lets read file
            StreamReader inputFile;

            try
            {
                // finds and opens file
                inputFile = File.OpenText("Pet Info.txt");

                while (!inputFile.EndOfStream)
                {
                    string[] token = inputFile.ReadLine().Split(',');
                    // adds to list
                    Lists.petZ.Add(new Pet(token[0], token[1], int.Parse(token[2])));
                }
                inputFile.Close();
                return "Loaded";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }
    }
}
