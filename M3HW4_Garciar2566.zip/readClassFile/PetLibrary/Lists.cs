﻿/**
* 26092021
* CSC 253
* Rebecca Garcia
* Class to & from File
*/using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PetLibrary
{
    public static class Lists
    {   // list to save file contents that accessible prog wide
        public static List<Pet> petZ = new List<Pet>();
    }
}