﻿/**
* 24102021
* CSC 253
* Rebecca Garcia
* M5HW2 - ShiftSupervisor Class
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace empProLibrary
{
    public class employeeClass
    {
        // parent Class
        public employeeClass(string empname, string empnum)
        {
            empName = empname;
            empNum = empnum;
        }

        // auto prop
        public string empName { get; set; }

        public string empNum  { get; set; }
    }
}
