﻿/**
* 24102021
* CSC 253
* Rebecca Garcia
* M5HW2 - ShiftSupervisor Class
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using empProLibrary;

namespace WinsUI
{
    public partial class M5HW1 : Form
    {
        public M5HW1()
        {
            InitializeComponent();
        }       

        private void addButton_Click(object sender, EventArgs e)
        {
            // temp variables
            decimal hourPay = 0;
            decimal annualPay = 0;
            decimal annualBonus = 0;


            // creates worker obj
            shiftSupervisorClass employee = new shiftSupervisorClass(nameTextbox.Text, numTextbox.Text, annualPay, annualBonus);
            employee.empName  =  nameTextbox.Text;
            employee.empNum   =   numTextbox.Text;


            if (shiftTextbox.Text == "1" || shiftTextbox.Text == "2")
            {
                
                 // loop for if input is not a 1 or 2
            if (decimal.TryParse(payTextbox.Text, out hourPay))
            {
                annualPay = (hourPay * 50) * 52;
            }
            else
            {
                MessageBox.Show("Incorrect input for pay rate entered", "ERROR: Invalid Entry...");
            }
            }
            else {
                MessageBox.Show("For 'Shift Number'\n   ONLY enter 1 OR 2\n   1 > Day Shift\n   2 > Night Shift", "ERROR: Invalid Entry...");

            }


            // loop for if input is not decimal
            if (decimal.TryParse(payTextbox.Text, out hourPay))
            {
                annualPay = (hourPay * 50) * 52; 
                employee.annualSalary = annualPay;

                // Displays output
                nameDisplay.Text = employee.empName;
                numDisplay.Text = employee.empNum;


                if (shiftTextbox.Text == "1")
                {
                    shiftDisplay.Text = "1/Day Shift";
                }

                if (shiftTextbox.Text == "2")
                {
                    shiftDisplay.Text = "2/Night Shift";
                }

                payDisplay.Text = employee.annualSalary.ToString("c"); //currency format


                if (employee.annualSalary >= 65000) //makeshift bonus loop to go along with assignment senario
                {
                    employee.annualBonus = 10000;

                    bonusDisplay.Text = employee.annualBonus.ToString("c");

                }
                else 
                {
                    employee.annualBonus = 12000;

                    bonusDisplay.Text = employee.annualBonus.ToString("c");

                }
            }
            else
            {
                MessageBox.Show("Incorrect input for pay rate entered", "ERROR: Invalid Entry...");
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            //clears textbox
            payTextbox.Clear();
            numTextbox.Clear();
            nameTextbox.Clear();
            shiftTextbox.Clear();

            //clears labels       
            shiftDisplay.Text = "";
            bonusDisplay.Text = "";
            nameDisplay.Text = "";
            payDisplay.Text = "";
            numDisplay.Text = "";            
        }

    }
}
