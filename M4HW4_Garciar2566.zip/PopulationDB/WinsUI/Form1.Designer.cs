﻿
namespace WinsUI
{
    partial class popDBForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.cityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.populationDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cityBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.populationDBDataSet = new WinsUI.PopulationDBDataSet();
            this.cityTableAdapter = new WinsUI.PopulationDBDataSetTableAdapters.CityTableAdapter();
            this.titleLabel = new System.Windows.Forms.Label();
            this.sortPopAsc = new System.Windows.Forms.Button();
            this.sortPopDesc = new System.Windows.Forms.Button();
            this.sortCity = new System.Windows.Forms.Button();
            this.totalPop = new System.Windows.Forms.Button();
            this.avgPop = new System.Windows.Forms.Button();
            this.highPop = new System.Windows.Forms.Button();
            this.lowPop = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cityBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.populationDBDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.cityDataGridViewTextBoxColumn,
            this.populationDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.cityBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(12, 66);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(240, 501);
            this.dataGridView1.TabIndex = 0;
            // 
            // cityDataGridViewTextBoxColumn
            // 
            this.cityDataGridViewTextBoxColumn.DataPropertyName = "City";
            this.cityDataGridViewTextBoxColumn.HeaderText = "City";
            this.cityDataGridViewTextBoxColumn.Name = "cityDataGridViewTextBoxColumn";
            // 
            // populationDataGridViewTextBoxColumn
            // 
            this.populationDataGridViewTextBoxColumn.DataPropertyName = "Population";
            this.populationDataGridViewTextBoxColumn.HeaderText = "Population";
            this.populationDataGridViewTextBoxColumn.Name = "populationDataGridViewTextBoxColumn";
            // 
            // cityBindingSource
            // 
            this.cityBindingSource.DataMember = "City";
            this.cityBindingSource.DataSource = this.populationDBDataSet;
            // 
            // populationDBDataSet
            // 
            this.populationDBDataSet.DataSetName = "PopulationDBDataSet";
            this.populationDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // cityTableAdapter
            // 
            this.cityTableAdapter.ClearBeforeFill = true;
            // 
            // titleLabel
            // 
            this.titleLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titleLabel.Location = new System.Drawing.Point(83, 9);
            this.titleLabel.Name = "titleLabel";
            this.titleLabel.Size = new System.Drawing.Size(370, 48);
            this.titleLabel.TabIndex = 3;
            this.titleLabel.Text = "Population Database";
            this.titleLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // sortPopAsc
            // 
            this.sortPopAsc.Location = new System.Drawing.Point(283, 197);
            this.sortPopAsc.Name = "sortPopAsc";
            this.sortPopAsc.Size = new System.Drawing.Size(99, 35);
            this.sortPopAsc.TabIndex = 2;
            this.sortPopAsc.Text = "Sort Population, Ascending";
            this.sortPopAsc.UseVisualStyleBackColor = true;
            this.sortPopAsc.Click += new System.EventHandler(this.sortPopAsc_Click);
            // 
            // sortPopDesc
            // 
            this.sortPopDesc.Location = new System.Drawing.Point(417, 197);
            this.sortPopDesc.Name = "sortPopDesc";
            this.sortPopDesc.Size = new System.Drawing.Size(99, 35);
            this.sortPopDesc.TabIndex = 3;
            this.sortPopDesc.Text = "Sort Population, Descending";
            this.sortPopDesc.UseVisualStyleBackColor = true;
            this.sortPopDesc.Click += new System.EventHandler(this.sortPopDesc_Click);
            // 
            // sortCity
            // 
            this.sortCity.Location = new System.Drawing.Point(354, 116);
            this.sortCity.Name = "sortCity";
            this.sortCity.Size = new System.Drawing.Size(99, 35);
            this.sortCity.TabIndex = 1;
            this.sortCity.Text = "Sort City";
            this.sortCity.UseVisualStyleBackColor = true;
            this.sortCity.Click += new System.EventHandler(this.sortCity_Click);
            // 
            // totalPop
            // 
            this.totalPop.Location = new System.Drawing.Point(283, 320);
            this.totalPop.Name = "totalPop";
            this.totalPop.Size = new System.Drawing.Size(99, 35);
            this.totalPop.TabIndex = 4;
            this.totalPop.Text = "Total Population";
            this.totalPop.UseVisualStyleBackColor = true;
            this.totalPop.Click += new System.EventHandler(this.totalPop_Click);
            // 
            // avgPop
            // 
            this.avgPop.Location = new System.Drawing.Point(417, 320);
            this.avgPop.Name = "avgPop";
            this.avgPop.Size = new System.Drawing.Size(99, 35);
            this.avgPop.TabIndex = 5;
            this.avgPop.Text = "Average Population";
            this.avgPop.UseVisualStyleBackColor = true;
            this.avgPop.Click += new System.EventHandler(this.avgPop_Click);
            // 
            // highPop
            // 
            this.highPop.Location = new System.Drawing.Point(283, 443);
            this.highPop.Name = "highPop";
            this.highPop.Size = new System.Drawing.Size(99, 35);
            this.highPop.TabIndex = 6;
            this.highPop.Text = "Highest Population";
            this.highPop.UseVisualStyleBackColor = true;
            this.highPop.Click += new System.EventHandler(this.highPop_Click);
            // 
            // lowPop
            // 
            this.lowPop.Location = new System.Drawing.Point(417, 443);
            this.lowPop.Name = "lowPop";
            this.lowPop.Size = new System.Drawing.Size(99, 35);
            this.lowPop.TabIndex = 7;
            this.lowPop.Text = "Lowest Population";
            this.lowPop.UseVisualStyleBackColor = true;
            this.lowPop.Click += new System.EventHandler(this.lowPop_Click);
            // 
            // popDBForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(540, 579);
            this.Controls.Add(this.lowPop);
            this.Controls.Add(this.highPop);
            this.Controls.Add(this.avgPop);
            this.Controls.Add(this.totalPop);
            this.Controls.Add(this.sortCity);
            this.Controls.Add(this.sortPopDesc);
            this.Controls.Add(this.sortPopAsc);
            this.Controls.Add(this.titleLabel);
            this.Controls.Add(this.dataGridView1);
            this.Name = "popDBForm";
            this.Text = "M4HW4_Garcia2566";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cityBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.populationDBDataSet)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private PopulationDBDataSet populationDBDataSet;
        private System.Windows.Forms.BindingSource cityBindingSource;
        private PopulationDBDataSetTableAdapters.CityTableAdapter cityTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn cityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn populationDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.Button sortPopAsc;
        private System.Windows.Forms.Button sortPopDesc;
        private System.Windows.Forms.Button sortCity;
        private System.Windows.Forms.Button totalPop;
        private System.Windows.Forms.Button avgPop;
        private System.Windows.Forms.Button highPop;
        private System.Windows.Forms.Button lowPop;
    }
}

