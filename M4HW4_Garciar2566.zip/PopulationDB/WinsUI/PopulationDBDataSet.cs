﻿namespace WinsUI
{


    partial class PopulationDBDataSet
    {
    }
}

