﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinsUI
{
    public partial class popDBForm : Form
    {
        public popDBForm()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'populationDBDataSet.City' table. You can move, or remove it, as needed.
            this.cityTableAdapter.Fill(this.populationDBDataSet.City);

        }

        private void sortCity_Click(object sender, EventArgs e)
        {
            this.cityTableAdapter.cityAZ_FillBy(this.populationDBDataSet.City);
        }

        private void sortPopAsc_Click(object sender, EventArgs e)
        {
            this.cityTableAdapter.popAsc_FillBy(this.populationDBDataSet.City);
        }

        private void sortPopDesc_Click(object sender, EventArgs e)
        {
            this.cityTableAdapter.popDesc_FillBy(this.populationDBDataSet.City);
        }

        private void totalPop_Click(object sender, EventArgs e)
        {
            decimal totPop;

            totPop = (decimal)this.cityTableAdapter.popTotal();

            MessageBox.Show("Total Population: " + totPop.ToString("n"));
        }

        private void avgPop_Click(object sender, EventArgs e)
        {
            decimal avgPop;

            avgPop = (decimal)this.cityTableAdapter.popAvg();

            MessageBox.Show("Average Population: " + avgPop.ToString("n"));
        }

        private void highPop_Click(object sender, EventArgs e)
        {
            decimal hiPop;

            hiPop = (decimal)this.cityTableAdapter.popHigh();

            MessageBox.Show("Highest Population: " + hiPop.ToString("n"));
        }

        private void lowPop_Click(object sender, EventArgs e)
        {
            decimal lowPop;

            lowPop = (decimal)this.cityTableAdapter.popLow();

            MessageBox.Show("Lowest Population: " + lowPop.ToString("n"));
        }
    }
}
