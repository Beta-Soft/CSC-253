﻿/**
* 26092021
* CSC 253
* Rebecca Garcia
* Class to File
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PetLibrary;

namespace WinsUI
{
    public partial class classToFile : Form
    {
        public classToFile()
        {
            InitializeComponent();
        }

        Pet pet;

        private void submitButton_Click(object sender, EventArgs e)
        {
            string name = txtName.Text, type = txtType.Text;
            int age = 0;
            if (!string.IsNullOrWhiteSpace(name) && !string.IsNullOrWhiteSpace(type) && int.TryParse(txtAge.Text, out age))
            {
                pet = new Pet(name, type, age);

                displayBox.Items.Add(Writer.writerFile(name, type, age));
            }
            else
                MessageBox.Show("Please enter input!");
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close(); // exits
        }
    }
}
