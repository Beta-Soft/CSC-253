﻿namespace WinsUI
{
    partial class FileWriter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ranLabel = new System.Windows.Forms.Label();
            this.numText = new System.Windows.Forms.TextBox();
            this.fileButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.label = new System.Windows.Forms.Label();
            this.numBox = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // ranLabel
            // 
            this.ranLabel.AutoSize = true;
            this.ranLabel.Location = new System.Drawing.Point(16, 71);
            this.ranLabel.Name = "ranLabel";
            this.ranLabel.Size = new System.Drawing.Size(208, 13);
            this.ranLabel.TabIndex = 0;
            this.ranLabel.Text = "Enter quantity of random numbers to write: ";
            // 
            // numText
            // 
            this.numText.Location = new System.Drawing.Point(221, 71);
            this.numText.Name = "numText";
            this.numText.Size = new System.Drawing.Size(78, 20);
            this.numText.TabIndex = 1;
            // 
            // fileButton
            // 
            this.fileButton.Location = new System.Drawing.Point(116, 101);
            this.fileButton.Name = "fileButton";
            this.fileButton.Size = new System.Drawing.Size(75, 23);
            this.fileButton.TabIndex = 2;
            this.fileButton.Text = "Write to File";
            this.fileButton.UseVisualStyleBackColor = true;
            this.fileButton.Click += new System.EventHandler(this.fileButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(116, 214);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 3;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // label
            // 
            this.label.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label.Location = new System.Drawing.Point(12, 9);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(305, 58);
            this.label.TabIndex = 23;
            this.label.Text = "FILE WRITER";
            this.label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // numBox
            // 
            this.numBox.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.numBox.FormattingEnabled = true;
            this.numBox.Location = new System.Drawing.Point(19, 140);
            this.numBox.Name = "numBox";
            this.numBox.Size = new System.Drawing.Size(280, 56);
            this.numBox.TabIndex = 24;
            this.numBox.TabStop = false;
            // 
            // FileWriter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(322, 247);
            this.Controls.Add(this.numBox);
            this.Controls.Add(this.label);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.fileButton);
            this.Controls.Add(this.numText);
            this.Controls.Add(this.ranLabel);
            this.Name = "FileWriter";
            this.Text = "File Writer";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label ranLabel;
        private System.Windows.Forms.TextBox numText;
        private System.Windows.Forms.Button fileButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label label;
        private System.Windows.Forms.ListBox numBox;
    }
}

