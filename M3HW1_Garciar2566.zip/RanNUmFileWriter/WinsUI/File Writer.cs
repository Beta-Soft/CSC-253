﻿/**
* 19092021
* CSC 253
* Rebecca Garcia
* File Writer
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RanLib;

namespace WinsUI
{
    public partial class FileWriter : Form
    {
        public FileWriter()
        {
            InitializeComponent();
        }

        RandomNumber RandomNumber; // cal class library

        private void fileButton_Click(object sender, EventArgs e)
        {
            int userNum = 0;
            if (int.TryParse(numText.Text, out userNum))
            {
                RandomNumber = new RandomNumber(userNum); // uses lib
                numBox.Items.Add("Amount entered: " + RandomNumber.UserRandom);
                numBox.Items.Add(RandomNumber.randomFile(userNum));
            }
            else // if non-int or nothing input
                MessageBox.Show("Enter Valid Input", "Error");
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close(); // exits program
        }
    }
}
