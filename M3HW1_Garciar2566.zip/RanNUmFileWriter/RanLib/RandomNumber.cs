﻿/**
* 19092021
* CSC 253
* Rebecca Garcia
* File Writer
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace RanLib
{
    public class RandomNumber
    {
        public RandomNumber(int userRandom)
        {
            UserRandom = userRandom;
        }

        public int UserRandom { get; set; }
        public static string randomFile(int userRandom)
        {
            int ranNum = 0; // starts ran num at 0
            try
            {

                StreamWriter fileOutput; // names file 

                fileOutput = File.CreateText("Random_Writer.txt"); // creates file

                Random numberRan = new Random();


                for (int count = 0; count < userRandom; count++) // loop for amount of num user inputs
                {
                    ranNum = numberRan.Next(1, 101);
                    fileOutput.WriteLine(ranNum);
                }

                fileOutput.Close();

                string createDisplay = "File with " + userRandom + " entries has been created!";

                return createDisplay;
            }
            catch (Exception ex)
            {
                string run = (ex.Message);
                return run;
            }
        }
    }
}
