﻿/**
* 05092021
* CSC 253
* Rebecca Garcia
* Word Count Pt2
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WordCountLibX
{
    public class WordCount
    {
        public WordCount(string userText)
        {
            usertext = userText;
        }

        public string usertext { get; set; }
    }
}
