﻿/**
* 05092021
* CSC 253
* Rebecca Garcia
* Word Count Pt2
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WordCountLibX;

namespace WinsUI
{
    public partial class FormWordCount : Form
    {
        public FormWordCount()
        {
            InitializeComponent();
        }

        WordCount wordcount;

        private void addWordButton_Click(object sender, EventArgs e)
        {
            string userTextInput = richWordCount.Text.Trim();
            int count, word;

            count = 0;
            word = 1;

            // loop till end of string //
            while (count < userTextInput.Length)
            {
                // code to not count white space or new line into word count //
                if (userTextInput[count] == ' ' || userTextInput[count] == '\n')
                {
                    word++;
                }

                count++;
            }

            // input w/o spaces so count does not include
            string userTextSpace = userTextInput.Replace(" ", "");

            int numberOfLetters = 0;
            foreach (char letter in userTextSpace)
            {
                numberOfLetters++;
            }
            // calculates avg letters per word
            int avgLetters = numberOfLetters / word;

            // messagebox letting user know nothing has been entered //
            if (!string.IsNullOrWhiteSpace(userTextInput))
            {
                wordcount = new WordCount(userTextInput);
            }
            else
                MessageBox.Show("Please input words for count!", "Invalid Input");
            
            try
            {                                      // replaces user newline as space for output of words entered //
                wordBox.Items.Add("Word Input: " + wordcount.usertext.Replace(System.Environment.NewLine, " "));
                wordBox.Items.Add("Word Count: \n" + word);
                wordBox.Items.Add("Letters: \n" + numberOfLetters);
                wordBox.Items.Add("Avg letters per word: \n" + avgLetters);
                wordBox.Items.Add("----------------------------------------");
            }
            catch (NullReferenceException)
            {
                MessageBox.Show("Submit entry first!", "Invalid Input");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // clears text for new word entry to be stored in wordBox
        private void newWordButton_Click(object sender, EventArgs e)
        {
            richWordCount.Text = " ";
        }

        // clears form
        private void clearButton_Click(object sender, EventArgs e)
        {
            wordBox.Items.Clear();
            richWordCount.Text = " ";
        }
    }
}
