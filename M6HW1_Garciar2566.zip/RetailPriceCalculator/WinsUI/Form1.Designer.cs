﻿
namespace WinsUI
{
    partial class M6HW1_Garciar2566
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.titleLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.costLabel = new System.Windows.Forms.Label();
            this.markupLabel = new System.Windows.Forms.Label();
            this.wholeText = new System.Windows.Forms.TextBox();
            this.percentText = new System.Windows.Forms.TextBox();
            this.outputBox = new System.Windows.Forms.ListBox();
            this.buttonClear = new System.Windows.Forms.Button();
            this.buttonExit = new System.Windows.Forms.Button();
            this.percentLabel = new System.Windows.Forms.Label();
            this.buttonCalc = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // titleLabel
            // 
            this.titleLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titleLabel.Location = new System.Drawing.Point(24, 9);
            this.titleLabel.Name = "titleLabel";
            this.titleLabel.Size = new System.Drawing.Size(256, 80);
            this.titleLabel.TabIndex = 0;
            this.titleLabel.Text = "Retail Price Calculator";
            this.titleLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(57, 100);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(186, 67);
            this.label1.TabIndex = 1;
            this.label1.Text = "Enter an items wholesale cost and\r\nits markup percentage, to display\r\nthe item\'s " +
    "new price\r\n";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // costLabel
            // 
            this.costLabel.AutoSize = true;
            this.costLabel.Location = new System.Drawing.Point(39, 185);
            this.costLabel.Name = "costLabel";
            this.costLabel.Size = new System.Drawing.Size(111, 13);
            this.costLabel.TabIndex = 2;
            this.costLabel.Text = "Enter whole sale cost:";
            // 
            // markupLabel
            // 
            this.markupLabel.AutoSize = true;
            this.markupLabel.Location = new System.Drawing.Point(20, 213);
            this.markupLabel.Name = "markupLabel";
            this.markupLabel.Size = new System.Drawing.Size(130, 13);
            this.markupLabel.TabIndex = 3;
            this.markupLabel.Text = "Enter markup percentage:";
            // 
            // wholeText
            // 
            this.wholeText.Location = new System.Drawing.Point(156, 182);
            this.wholeText.Name = "wholeText";
            this.wholeText.Size = new System.Drawing.Size(100, 20);
            this.wholeText.TabIndex = 1;
            // 
            // percentText
            // 
            this.percentText.Location = new System.Drawing.Point(156, 213);
            this.percentText.Name = "percentText";
            this.percentText.Size = new System.Drawing.Size(30, 20);
            this.percentText.TabIndex = 2;
            // 
            // outputBox
            // 
            this.outputBox.FormattingEnabled = true;
            this.outputBox.Location = new System.Drawing.Point(23, 273);
            this.outputBox.Name = "outputBox";
            this.outputBox.Size = new System.Drawing.Size(248, 95);
            this.outputBox.TabIndex = 6;
            // 
            // buttonClear
            // 
            this.buttonClear.Location = new System.Drawing.Point(181, 244);
            this.buttonClear.Name = "buttonClear";
            this.buttonClear.Size = new System.Drawing.Size(75, 23);
            this.buttonClear.TabIndex = 4;
            this.buttonClear.Text = "Clear";
            this.buttonClear.UseVisualStyleBackColor = true;
            this.buttonClear.Click += new System.EventHandler(this.buttonClear_Click);
            // 
            // buttonExit
            // 
            this.buttonExit.Location = new System.Drawing.Point(111, 389);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(75, 23);
            this.buttonExit.TabIndex = 5;
            this.buttonExit.Text = "Exit";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // percentLabel
            // 
            this.percentLabel.AutoSize = true;
            this.percentLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.percentLabel.Location = new System.Drawing.Point(192, 214);
            this.percentLabel.Name = "percentLabel";
            this.percentLabel.Size = new System.Drawing.Size(21, 16);
            this.percentLabel.TabIndex = 9;
            this.percentLabel.Text = "%";
            // 
            // buttonCalc
            // 
            this.buttonCalc.Location = new System.Drawing.Point(42, 244);
            this.buttonCalc.Name = "buttonCalc";
            this.buttonCalc.Size = new System.Drawing.Size(75, 23);
            this.buttonCalc.TabIndex = 3;
            this.buttonCalc.Text = "Calc";
            this.buttonCalc.UseVisualStyleBackColor = true;
            this.buttonCalc.Click += new System.EventHandler(this.buttonCalc_Click);
            // 
            // M6HW1_Garciar2566
            // 
            this.AcceptButton = this.buttonCalc;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(304, 424);
            this.Controls.Add(this.buttonCalc);
            this.Controls.Add(this.percentLabel);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.buttonClear);
            this.Controls.Add(this.outputBox);
            this.Controls.Add(this.percentText);
            this.Controls.Add(this.wholeText);
            this.Controls.Add(this.markupLabel);
            this.Controls.Add(this.costLabel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.titleLabel);
            this.Name = "M6HW1_Garciar2566";
            this.Text = "M6HW1_Garciar2566";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label costLabel;
        private System.Windows.Forms.Label markupLabel;
        private System.Windows.Forms.TextBox wholeText;
        private System.Windows.Forms.TextBox percentText;
        private System.Windows.Forms.ListBox outputBox;
        private System.Windows.Forms.Button buttonClear;
        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Label percentLabel;
        private System.Windows.Forms.Button buttonCalc;
    }
}

