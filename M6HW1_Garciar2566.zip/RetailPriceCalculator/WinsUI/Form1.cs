﻿/**
* CSC 253
* Rebecca Garcia 
* M6HW1 -Unit Testing
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RetailPriceLibrary;

namespace WinsUI
{
    public partial class M6HW1_Garciar2566 : Form
    {
        public M6HW1_Garciar2566()
        {
            InitializeComponent();
        }

        private void buttonCalc_Click(object sender, EventArgs e)
        {
            decimal cost, markup, retailPrice, markupAmount, percent;
            string x = "\t      ";
            try
            {
                cost         = decimal.Parse(wholeText.Text);
                markup       = decimal.Parse(percentText.Text);
                percent      = markup / 100;
                markupAmount = cost * percent;
                
                retailPrice  = calcRetail.CalcRetail(cost, markup);

                outputBox.Items.Add(x + "Wholesale Price: $" + cost);
                outputBox.Items.Add(x + "Markup: "           + markup + "%");
                outputBox.Items.Add(x + "Markup Amount: $"   + markupAmount);
                outputBox.Items.Add(x + "Retail Price: "     + retailPrice.ToString("C"));
                outputBox.Items.Add(x + "-------------------------------------");
            }
            catch
            {
                MessageBox.Show("Please Enter a VALID numerical value!...", "ERROR!",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }            
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
                  wholeText.Clear();
                percentText.Clear();
            outputBox.Items.Clear();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
