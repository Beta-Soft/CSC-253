﻿/**
* CSC 253
* Rebecca Garcia 
* M6HW1 -Unit Testing
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RetailPriceLibrary
{
    public static class calcRetail
    {        
        public static decimal CalcRetail(decimal cost, decimal markup)
        {
            decimal percent = markup / 100;
            decimal retailPrice = cost + (cost * percent);
            return retailPrice;
        }
    }
}
