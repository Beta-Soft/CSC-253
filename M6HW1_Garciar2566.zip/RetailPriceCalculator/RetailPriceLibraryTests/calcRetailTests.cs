﻿/**
* CSC 253
* Rebecca Garcia 
* M6HW1 -Unit Testing
*/

using Microsoft.VisualStudio.TestTools.UnitTesting;
using RetailPriceLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RetailPriceLibrary.Tests
{
    [TestClass()]
    public class calcRetailTests
    {
        [TestMethod()]
        public void calcRetailTest()
        {
            // arrange
            decimal Cost = 10;
            decimal Markup = 2;

            decimal expected = 10.2m;

            // act
            var result = RetailPriceLibrary.calcRetail.CalcRetail(Cost, Markup);

            // assert
            Assert.AreEqual(expected, result);

        }
    }
}